self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "691ffa8f88b80ae3ca0b30bc257c174e",
    "url": "/index.html"
  },
  {
    "revision": "2a4895da3f71fc35d92d",
    "url": "/static/css/main.a57f434c.chunk.css"
  },
  {
    "revision": "056dd7d24f74ba5c6065",
    "url": "/static/js/2.14b9355f.chunk.js"
  },
  {
    "revision": "0749163b59fbee32225059cb60c18af6",
    "url": "/static/js/2.14b9355f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2a4895da3f71fc35d92d",
    "url": "/static/js/main.723c2ff1.chunk.js"
  },
  {
    "revision": "b487febcf3bf1536e770",
    "url": "/static/js/runtime-main.cb74dc36.js"
  },
  {
    "revision": "f28edf9d13588abcaf639d8e27747df6",
    "url": "/static/media/BlackAndWhiteSwarovskiCrystalNecklace.f28edf9d.png"
  },
  {
    "revision": "66cc1d2b32be1d49e68b84ca70e3bd14",
    "url": "/static/media/BlackEyeEngagementRing.66cc1d2b.png"
  },
  {
    "revision": "e576a325104115c9a1e5ddb973e33712",
    "url": "/static/media/BlackSwarovskiCrystalSwanNecklace.e576a325.png"
  },
  {
    "revision": "cf68398f250c58610c329ad74a5d2b3e",
    "url": "/static/media/BlueEyeDiamondEngagementRing.cf68398f.png"
  },
  {
    "revision": "a50926a9400a93fc2fc71f439e9c9e1b",
    "url": "/static/media/BlueEyeEngagementRing.a50926a9.png"
  },
  {
    "revision": "a483dce2f4846f4cc57795da26c8ee5b",
    "url": "/static/media/BlueEyeSilverBracelet.a483dce2.png"
  },
  {
    "revision": "1cc19d4f19dcd6cf8ff66d60dc2832d6",
    "url": "/static/media/BlueWhiteSwarovskiCrystalEarings.1cc19d4f.png"
  },
  {
    "revision": "fb0449dae1f687ecf91d2d48adb650d9",
    "url": "/static/media/ClassicSilverWeddingRings.fb0449da.png"
  },
  {
    "revision": "7362dc6371cc5a83f3ab101b274b727f",
    "url": "/static/media/DiamondEyeSilverWeddingRings.7362dc63.png"
  },
  {
    "revision": "3f247457168d3f5b65a2da27f92f9083",
    "url": "/static/media/DiamondEyesSilverWeddingRings.3f247457.png"
  },
  {
    "revision": "e29b2424f11babb6d638beddee21b05f",
    "url": "/static/media/EmeraldBracelet.e29b2424.png"
  },
  {
    "revision": "b6551f57544ccb7b744f8493203b05af",
    "url": "/static/media/EmeraldEyeDiamondNecklace.b6551f57.png"
  },
  {
    "revision": "36dfd39ba6d5aeb414eac4d2772a4672",
    "url": "/static/media/EmeraldEyeEngagementRing.36dfd39b.png"
  },
  {
    "revision": "0c309876d098cdccea57311c8e339cda",
    "url": "/static/media/EmeraldEyeNecklace.0c309876.png"
  },
  {
    "revision": "6b2900cb25376fe78c1b2ffcae9469be",
    "url": "/static/media/GoldBangle.6b2900cb.png"
  },
  {
    "revision": "2cb2623ed8ffbc16aab4b9b8bc6414ff",
    "url": "/static/media/GoldCrystalBracelet.2cb2623e.png"
  },
  {
    "revision": "5c17fb8e8da37ade7bc1a52d49ec1f9d",
    "url": "/static/media/GoldDiamondEarings.5c17fb8e.png"
  },
  {
    "revision": "a9472370bf76aec6b3af81a1654ec385",
    "url": "/static/media/GoldSilverFlowerNecklace.a9472370.png"
  },
  {
    "revision": "02c0db54a2e4caa644d8218cbb70f6ce",
    "url": "/static/media/GoldSilverWeddingRings.02c0db54.png"
  },
  {
    "revision": "2c41a7dd58b394226538a1073cdb60e5",
    "url": "/static/media/OceanBondBracelet.2c41a7dd.png"
  },
  {
    "revision": "ee2ccc26478e00adfff66612a019fd4e",
    "url": "/static/media/PearlGoldBracelet.ee2ccc26.png"
  },
  {
    "revision": "b88d4966e171e03c7c8bf857f6232d43",
    "url": "/static/media/PearlWhiteCrystalEarings.b88d4966.png"
  },
  {
    "revision": "d722da1675923f71fc5b908466a4da31",
    "url": "/static/media/PearlWhiteGoldEarings.d722da16.png"
  },
  {
    "revision": "6798eea31c1363e170345641337868b8",
    "url": "/static/media/PinkButterflyCrystalEngagementRing.6798eea3.png"
  },
  {
    "revision": "5f7354e827df9fb716cf2303c80ec574",
    "url": "/static/media/PinkCrystalDiamondEarings.5f7354e8.png"
  },
  {
    "revision": "6ebae947c66ae80f2c04181b418476c0",
    "url": "/static/media/PurpleCrystalBracelet.6ebae947.png"
  },
  {
    "revision": "e22dad449b16ab2365fe55251067907c",
    "url": "/static/media/PurpleCrystalEarings.e22dad44.png"
  },
  {
    "revision": "001fee1ea58f41e726ba9e1e0998789b",
    "url": "/static/media/RubyDiamondEarings.001fee1e.png"
  },
  {
    "revision": "660fd5498114105e9e15a50e83d12aff",
    "url": "/static/media/RubyEyeEngagementRing.660fd549.png"
  },
  {
    "revision": "efc2ea79819f9c4b4f133529191da6db",
    "url": "/static/media/RubyFlowerEngagementRing.efc2ea79.png"
  },
  {
    "revision": "4d0f2e13fa7a2faf98d5d16fb274dc7a",
    "url": "/static/media/SapphireBangle.4d0f2e13.png"
  },
  {
    "revision": "bcbae63b48e9d6cc607b5269289e5716",
    "url": "/static/media/SapphireDiamondEngagementRing.bcbae63b.png"
  },
  {
    "revision": "59578228d10298da79a5b05b83ae228d",
    "url": "/static/media/SapphireEyeEngagementRing.59578228.png"
  },
  {
    "revision": "e75fc97ee3e1f391484bd890517e46fd",
    "url": "/static/media/SapphireEyeSilverNecklace.e75fc97e.png"
  },
  {
    "revision": "cb5fb64466b2d6798aeed6fdbb512013",
    "url": "/static/media/SapphireSilverEngagementRing.cb5fb644.png"
  },
  {
    "revision": "59b6ae9b13bba35dbdb1bcd25754b99f",
    "url": "/static/media/SapphireSwarovskiCrystalSilverNecklace.59b6ae9b.png"
  },
  {
    "revision": "b8680750d353848ac1396d1c754bac7f",
    "url": "/static/media/SapphireWhiteDiamondsEarings.b8680750.png"
  },
  {
    "revision": "8c2e5606be6c9441e8cd861faf3d8089",
    "url": "/static/media/SilverCrystalBracelet.8c2e5606.png"
  },
  {
    "revision": "a4f913c4da740106120cdcdca12b09a1",
    "url": "/static/media/SilverDiamondWeddingRing.a4f913c4.png"
  },
  {
    "revision": "248c07353b89ceffcfa865f76a5f21a6",
    "url": "/static/media/SilverGoldWeddingRing.248c0735.png"
  },
  {
    "revision": "8889dbbc6e7d33d0aaf449d490dc62cf",
    "url": "/static/media/SilverHeartNecklace.8889dbbc.png"
  },
  {
    "revision": "b7735a9a0f5fee5ada4dd872922ffcf6",
    "url": "/static/media/SilverMattDiamondWeddingRings.b7735a9a.png"
  },
  {
    "revision": "3034cb09c81c580f7afbebc0871ddc76",
    "url": "/static/media/SnowflakeDiamondEarings.3034cb09.png"
  },
  {
    "revision": "0097b2b9e833a4faf349951b48f75d4d",
    "url": "/static/media/SwarovskiCrystalGoldBracelet.0097b2b9.png"
  },
  {
    "revision": "531cdb493c0f53c87fef488de6cdb544",
    "url": "/static/media/WhiteBlackDiamondWeddingRings.531cdb49.png"
  },
  {
    "revision": "c895bca1d3b53108b7e575bc8ce585b5",
    "url": "/static/media/WhiteDiamondNecklace.c895bca1.png"
  },
  {
    "revision": "bb2d369a78d66c7d27b9829466181f50",
    "url": "/static/media/WhiteDiamondSilverBracelet.bb2d369a.png"
  },
  {
    "revision": "9f3dacfd3235898e9d93c9d55b0b0bed",
    "url": "/static/media/WhiteDiamondsGoldDoubleBracelet.9f3dacfd.png"
  },
  {
    "revision": "cf2c012767bf25c50613111ed83ac889",
    "url": "/static/media/WhiteGoldDiamondsWeddingRings.cf2c0127.png"
  },
  {
    "revision": "8f757b2ab93ce8d3d62fac3becc2c3eb",
    "url": "/static/media/WhitePearlNecklace.8f757b2a.png"
  },
  {
    "revision": "aa69e9de7eca80885b0158ddb7734f10",
    "url": "/static/media/closeFilterSvg.aa69e9de.svg"
  },
  {
    "revision": "2d3b91309027cd08c4868ceeee5853b9",
    "url": "/static/media/diamond.2d3b9130.jpg"
  },
  {
    "revision": "2fa5eec5876111d8cf481856753f3a5c",
    "url": "/static/media/emerald.2fa5eec5.jpg"
  },
  {
    "revision": "7a18c53673ac1076306ff87029fab501",
    "url": "/static/media/ruby.7a18c536.jpg"
  },
  {
    "revision": "db8017e16b0d98c4ea0a7e67911f366c",
    "url": "/static/media/shoppingCartSvg.db8017e1.svg"
  },
  {
    "revision": "284964d6d24abcf0c856b41a707f03c1",
    "url": "/static/media/slide.284964d6.jpg"
  },
  {
    "revision": "0f9e22c6c8708459b3fa04e7cc023b0c",
    "url": "/static/media/slide2.0f9e22c6.jpg"
  },
  {
    "revision": "fdcdb4a49c54517603b955d83d652897",
    "url": "/static/media/slide3.fdcdb4a4.jpg"
  }
]);